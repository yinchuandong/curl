<?php 
include 'IsbnHelper.php';

$helper = new IsbnHelper();
$helper->getBookInfo('出现频率最高的100种典型题型精解精练');

?>